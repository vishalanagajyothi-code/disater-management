// ================================
// DISASTER MANAGEMENT SYSTEM
// script.js
// ================================


// Open Emergency Dashboard
function openDashboard() {
    window.location.href = "dashboard.html";
}


// Open Emergency Alert Page
function openAlert() {
    window.location.href = "alert.html";
}


// Open Map Page
function openMap() {
    window.location.href = "map.html";
}


// Open Safe Zones Page
function openShelters() {
    window.location.href = "shelters.html";
}


// Open Rescue Management Page
function openRescue() {
    window.location.href = "rescue.html";
}


// Open Reports Page
function openReports() {
    window.location.href = "reports.html";
}


// Emergency Alert Popup
function showEmergencyAlert(message) {

    alert(
        "🚨 EMERGENCY ALERT 🚨\n\n" +
        message +
        "\n\nPlease stay calm and follow safety instructions."
    );
}


// Test Emergency Alert
function testEmergencyAlert() {

    showEmergencyAlert(
        "Emergency situation detected. " +
        "Please move to the nearest safe zone."
    );
}


// Confirm Emergency Report
function confirmEmergencyReport() {

    const result = confirm(
        "🚨 Are you sure you want to report an emergency?"
    );

    if (result) {

        alert(
            "✅ Emergency reported successfully!\n\n" +
            "Emergency response team has been notified."
        );

    } else {

        alert(
            "Emergency report cancelled."
        );
    }
}


// Save Emergency Report
function saveEmergencyReport(type, location, severity) {

    const report = {

        type: type,
        location: location,
        severity: severity,
        date: new Date().toLocaleString(),
        status: "Under Investigation"

    };

    let reports =
        JSON.parse(localStorage.getItem("disasterReports")) || [];

    reports.push(report);

    localStorage.setItem(
        "disasterReports",
        JSON.stringify(reports)
    );

    alert(
        "✅ Emergency report submitted successfully!"
    );
}


// Get Saved Reports
function getEmergencyReports() {

    return JSON.parse(
        localStorage.getItem("disasterReports")
    ) || [];

}


// Clear All Reports
function clearEmergencyReports() {

    const confirmClear = confirm(
        "Are you sure you want to clear all reports?"
    );

    if (confirmClear) {

        localStorage.removeItem("disasterReports");

        alert(
            "All emergency reports have been cleared."
        );

        location.reload();
    }
}


// Page Navigation Helper
function navigateTo(page) {

    window.location.href = page;

}


// Show Current Date & Time
function showDateTime(elementId) {

    const element =
        document.getElementById(elementId);

    if (!element) return;

    const now = new Date();

    element.innerText =
        now.toLocaleString();

}


// Emergency Notification
function sendNotification(message) {

    alert(
        "🔔 EMERGENCY NOTIFICATION\n\n" +
        message
    );

}


// Logout / Return Home
function goHome() {

    window.location.href = "index.html";

}


// Console Message
console.log(
    "🚨 Disaster Management System Loaded Successfully"
);